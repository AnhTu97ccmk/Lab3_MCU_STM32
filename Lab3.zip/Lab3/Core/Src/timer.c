#include "main.h"
#include "timer.h"
#include "input_reading.h"

static volatile int     timer_counter[MAX_TIMER];
static volatile uint8_t timer_flag[MAX_TIMER];
static volatile uint32_t systemTimeMs;

void setTimer(int index, int duration_ms) {
    if (index < 0 || index >= MAX_TIMER) return;

    int ticks = (duration_ms + TIMER_CYCLE - 1) / TIMER_CYCLE;   /* làm tròn lên */
    if (ticks < 1) ticks = 1;

    __disable_irq();                 /* tránh ngắt chen vào giữa 2 lệnh gán */
    timer_counter[index] = ticks;
    timer_flag[index] = 0;
    __enable_irq();
}

int isTimerExpired(int index) {
    if (index < 0 || index >= MAX_TIMER) return 0;
    if (timer_flag[index]) {
        timer_flag[index] = 0;
        return 1;
    }
    return 0;
}

uint32_t getTimeMs(void) {
    return systemTimeMs;
}

void timerRun(void) {
    systemTimeMs += TIMER_CYCLE;
    for (int i = 0; i < MAX_TIMER; i++) {
        if (timer_counter[i] > 0) {
            timer_counter[i]--;
            if (timer_counter[i] == 0) timer_flag[i] = 1;
        }
    }
}

/* Ngắt TIM2: chạy software timer mỗi lần ngắt,
 * còn nút nhấn chỉ quét mỗi BUTTON_SCAN_MS (10ms) dù chu kỳ ngắt là bao nhiêu */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if (htim->Instance == TIM2) {
        static int scanDivider = 0;
        timerRun();
        if (++scanDivider >= BUTTON_SCAN_TICKS) {
            scanDivider = 0;
            button_reading();
        }
    }
}

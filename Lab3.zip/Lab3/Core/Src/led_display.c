#include "main.h"
#include "led_display.h"
#include "timer.h"

/* Theo sơ đồ Proteus: LED nối chung +3.3V => chân MCU = 0 thì LED sáng.
 * LED 7 đoạn common anode qua PNP => chân EN = 0 thì digit được bật, segment = 0 thì đoạn sáng.
 * Nếu sau này đổi mạch (active-high) chỉ cần sửa 4 macro này. */
#define LED_ON    GPIO_PIN_RESET
#define LED_OFF   GPIO_PIN_SET
#define EN_ON     GPIO_PIN_RESET
#define EN_OFF    GPIO_PIN_SET

#define SEG_MASK  0x007F      /* a..g = PB0..PB6 */

/* Đèn giao thông: [đường][đỏ, vàng, xanh]
 * Đường 1: A1 = đỏ, A2 = vàng, A3 = xanh (PA1, PA2, PA3)
 * Đường 2: A4 = đỏ, A5 = vàng, A6 = xanh (PA4, PA5, PA6) */
static GPIO_TypeDef * const ledPort[2][3] = {
    { A1_GPIO_Port, A2_GPIO_Port, A3_GPIO_Port },
    { A4_GPIO_Port, A5_GPIO_Port, A6_GPIO_Port }
};
static const uint16_t ledPin[2][3] = {
    { A1_Pin, A2_Pin, A3_Pin },
    { A4_Pin, A5_Pin, A6_Pin }
};

/* 4 chân enable digit: EN0..EN3 = PA7..PA10 */
static GPIO_TypeDef * const enPort[4] = { EN0_GPIO_Port, EN1_GPIO_Port, EN2_GPIO_Port, EN3_GPIO_Port };
static const uint16_t enPin[4]        = { EN0_Pin, EN1_Pin, EN2_Pin, EN3_Pin };

/* Vị trí hiển thị -> chỉ số EN. Theo hình vẽ:
 *   vị trí 0 = trên-trái  = EN1      vị trí 1 = trên-phải  = EN0
 *   vị trí 2 = dưới-trái  = EN2      vị trí 3 = dưới-phải  = EN3
 * (vị trí 0 là hàng chục, 1 là hàng đơn vị của cặp trên; 2 và 3 là của cặp dưới).
 * Nếu nối khác thì chỉ sửa bảng này. */
static const uint8_t positionToEN[4] = { 1, 0, 2, 3 };

/* Common anode: bit0 = a ... bit6 = g, bit = 0 thì đoạn sáng */
static const uint8_t SEG_CODE[10] = {
    0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x78, 0x00, 0x10
};

/* Output buffer */
static LightColor lightBuffer[2];
static uint8_t    digitBuffer[4];
static uint8_t    scanIndex;

void setLight(uint8_t road, LightColor color) {
    if (road > 1) return;
    lightBuffer[road] = color;
}

void setDisplayPair(uint8_t pair, int value) {
    if (pair > 1) return;
    if (value < 0)  value = 0;
    if (value > 99) value = 99;
    digitBuffer[pair * 2]     = (uint8_t)(value / 10);
    digitBuffer[pair * 2 + 1] = (uint8_t)(value % 10);
}

static void updateTrafficLeds(void) {
    for (uint8_t road = 0; road < 2; road++) {
        for (uint8_t c = 0; c < 3; c++) {
            /* c = 0,1,2 tương ứng LIGHT_RED(1), LIGHT_AMBER(2), LIGHT_GREEN(3) */
            GPIO_PinState s = (lightBuffer[road] == (LightColor)(c + 1)) ? LED_ON : LED_OFF;
            HAL_GPIO_WritePin(ledPort[road][c], ledPin[road][c], s);
        }
    }
}

/* a..g = PB0..PB6. Chỉ ghi đúng 7 bit này (dùng BSRR/BRR qua HAL_GPIO_WritePin),
 * tuyệt đối không ghi cả GPIOB->ODR vì PB7..PB9 là nút nhấn pull-up (bit ODR quyết định pull-up/pull-down). */
static void writeSegments(uint8_t code) {
    uint16_t high = (uint16_t)(code & SEG_MASK);          /* đoạn tắt  */
    uint16_t low  = (uint16_t)((~code) & SEG_MASK);       /* đoạn sáng */
    if (high) HAL_GPIO_WritePin(GPIOB, high, GPIO_PIN_SET);
    if (low)  HAL_GPIO_WritePin(GPIOB, low,  GPIO_PIN_RESET);
}

static void update7SEG(uint8_t position) {
    for (uint8_t i = 0; i < 4; i++)                       /* tắt hết digit trước khi đổi segment (tránh bóng mờ) */
        HAL_GPIO_WritePin(enPort[i], enPin[i], EN_OFF);

    writeSegments(SEG_CODE[digitBuffer[position]]);

    uint8_t en = positionToEN[position];
    HAL_GPIO_WritePin(enPort[en], enPin[en], EN_ON);
}

void display_init(void) {
    for (uint8_t i = 0; i < 4; i++)
        HAL_GPIO_WritePin(enPort[i], enPin[i], EN_OFF);
    lightBuffer[0] = LIGHT_OFF;
    lightBuffer[1] = LIGHT_OFF;
    scanIndex = 0;
    setTimer(TMR_SCAN, LED_SCAN_MS);
}

void display_update(void) {
    updateTrafficLeds();
    if (isTimerExpired(TMR_SCAN)) {
        setTimer(TMR_SCAN, LED_SCAN_MS);
        update7SEG(scanIndex);
        scanIndex = (uint8_t)((scanIndex + 1) % 4);
    }
}

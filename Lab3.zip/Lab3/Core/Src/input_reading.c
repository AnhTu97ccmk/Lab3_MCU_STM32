#include "main.h"
#include "input_reading.h"

/* Giữ 1 giây = 1000ms / chu kỳ quét */
#define DURATION_FOR_AUTO_INCREASING  (1000 / BUTTON_SCAN_PERIOD_MS)
#define BUTTON_IS_PRESSED   GPIO_PIN_RESET
#define BUTTON_IS_RELEASED  GPIO_PIN_SET

/* Nút nối theo sơ đồ: B1 = PB7 (mode), B2 = PB8 (tăng), B3 = PB9 (set)
 * User Label trong CubeMX: B1, B2, B3 */
static GPIO_TypeDef * const btnPort[N0_OF_BUTTONS] = {
    B1_GPIO_Port, B2_GPIO_Port, B3_GPIO_Port
};
static const uint16_t btnPin[N0_OF_BUTTONS] = {
    B1_Pin, B2_Pin, B3_Pin
};

static GPIO_PinState buttonBuffer[N0_OF_BUTTONS];            /* kết quả sau khi chống rung */
static GPIO_PinState debounceButtonBuffer1[N0_OF_BUTTONS];
static GPIO_PinState debounceButtonBuffer2[N0_OF_BUTTONS];
static uint8_t  flagForButtonPress1s[N0_OF_BUTTONS];
static uint16_t counterForButtonPress1s[N0_OF_BUTTONS];

/* Phải gọi 1 lần trước khi bật timer: mảng static mặc định = 0 = GPIO_PIN_RESET = "đang nhấn" */
void button_init(void) {
    for (uint8_t i = 0; i < N0_OF_BUTTONS; i++) {
        buttonBuffer[i] = BUTTON_IS_RELEASED;
        debounceButtonBuffer1[i] = BUTTON_IS_RELEASED;
        debounceButtonBuffer2[i] = BUTTON_IS_RELEASED;
        flagForButtonPress1s[i] = 0;
        counterForButtonPress1s[i] = 0;
    }
}

/* Gọi mỗi BUTTON_SCAN_MS (trong ngắt timer) */
void button_reading(void) {
    for (uint8_t i = 0; i < N0_OF_BUTTONS; i++) {
        debounceButtonBuffer2[i] = debounceButtonBuffer1[i];
        debounceButtonBuffer1[i] = HAL_GPIO_ReadPin(btnPort[i], btnPin[i]);   /* đọc đúng chân của nút i */

        if (debounceButtonBuffer1[i] == debounceButtonBuffer2[i])
            buttonBuffer[i] = debounceButtonBuffer1[i];

        if (buttonBuffer[i] == BUTTON_IS_PRESSED) {
            if (counterForButtonPress1s[i] < DURATION_FOR_AUTO_INCREASING) {
                counterForButtonPress1s[i]++;
            } else {
                flagForButtonPress1s[i] = 1;      /* đã giữ quá 1 giây */
            }
        } else {
            counterForButtonPress1s[i] = 0;
            flagForButtonPress1s[i] = 0;
        }
    }
}

unsigned char is_button_pressed(unsigned char index) {
    if (index >= N0_OF_BUTTONS) return 0;
    return (buttonBuffer[index] == BUTTON_IS_PRESSED);
}

unsigned char is_button_pressed_1s(unsigned char index) {
    if (index >= N0_OF_BUTTONS) return 0;
    return (flagForButtonPress1s[index] == 1);
}

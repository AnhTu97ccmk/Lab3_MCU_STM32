#include "main.h"
#include "input_reading.h"
#include "input_processing.h"
#include "led_display.h"
#include "timer.h"

/* =====================================================================
 *  PHẦN 1 (Ex5): FSM cho nút nhấn -> mỗi lần nhấn chỉ sinh ra 1 sự kiện
 * ===================================================================== */
enum ButtonState { BUTTON_RELEASED, BUTTON_PRESSED, BUTTON_PRESSED_MORE_THAN_1_SECOND };

#define AUTO_REPEAT_MS  500

static enum ButtonState buttonState[N0_OF_BUTTONS];          /* mặc định = BUTTON_RELEASED */
static uint8_t buttonEvent[N0_OF_BUTTONS];
/* chỉ nút 2 (tăng giá trị) mới tự lặp khi giữ > 1 giây; nút 1 (đổi mode) và nút 3 (set) thì không */
static const uint8_t autoRepeat[N0_OF_BUTTONS] = { 0, 1, 0 };

void fsm_for_input_processing(void) {
    for (uint8_t i = 0; i < N0_OF_BUTTONS; i++) {
        switch (buttonState[i]) {
        case BUTTON_RELEASED:
            if (is_button_pressed(i)) {
                buttonState[i] = BUTTON_PRESSED;
                buttonEvent[i] = 1;                              /* sự kiện "vừa nhấn" */
            }
            break;
        case BUTTON_PRESSED:
            if (!is_button_pressed(i)) {
                buttonState[i] = BUTTON_RELEASED;
            } else if (is_button_pressed_1s(i)) {
                buttonState[i] = BUTTON_PRESSED_MORE_THAN_1_SECOND;
                setTimer(TMR_BTN0 + i, AUTO_REPEAT_MS);
            }
            break;
        case BUTTON_PRESSED_MORE_THAN_1_SECOND:
            if (!is_button_pressed(i)) {
                buttonState[i] = BUTTON_RELEASED;
            } else if (autoRepeat[i] && isTimerExpired(TMR_BTN0 + i)) {
                buttonEvent[i] = 1;                              /* cứ 500ms thêm 1 sự kiện */
                setTimer(TMR_BTN0 + i, AUTO_REPEAT_MS);
            }
            break;
        }
    }
}

uint8_t button_event(uint8_t index) {
    if (index >= N0_OF_BUTTONS) return 0;
    uint8_t e = buttonEvent[index];
    buttonEvent[index] = 0;
    return e;
}

/* =====================================================================
 *  PHẦN 2: biến dùng chung cho mode / thời gian đèn
 * ===================================================================== */
int mode = MODE_NORMAL;
int durRed = 5, durAmber = 2, durGreen = 3;     /* giây; đỏ = xanh + vàng */
static int tempValue = 0;                       /* giá trị đang chỉnh ở Mode 2-4 */

#define BLINK_PERIOD_MS  500                    /* nháy 2Hz = 500ms/chu kỳ */

/* =====================================================================
 *  PHẦN 3 (Mode 1): FSM đèn giao thông 4 pha
 *    Đường 1 = LED nối net 1,2,3 ; Đường 2 = LED nối net 4,5,6
 * ===================================================================== */
typedef enum { PH_ROAD1_GREEN, PH_ROAD1_AMBER, PH_ROAD2_GREEN, PH_ROAD2_AMBER } TrafficPhase;
static TrafficPhase phase;
static int count1, count2;                      /* số giây còn lại của màu đang sáng ở mỗi đường */

static void enterPhase(TrafficPhase p) {
    phase = p;
    switch (p) {
    case PH_ROAD1_GREEN:
        setLight(0, LIGHT_GREEN); setLight(1, LIGHT_RED);
        count1 = durGreen;  count2 = durRed;   break;
    case PH_ROAD1_AMBER:
        setLight(0, LIGHT_AMBER); setLight(1, LIGHT_RED);
        count1 = durAmber;  count2 = durAmber; break;
    case PH_ROAD2_GREEN:
        setLight(0, LIGHT_RED);   setLight(1, LIGHT_GREEN);
        count1 = durRed;    count2 = durGreen; break;
    case PH_ROAD2_AMBER:
        setLight(0, LIGHT_RED);   setLight(1, LIGHT_AMBER);
        count1 = durAmber;  count2 = durAmber; break;
    }
}

/* =====================================================================
 *  PHẦN 4 (Ex6-9): mode, nháy LED, chỉnh thời gian
 * ===================================================================== */
static LightColor colorOfMode(int m) {
    return (m == 2) ? LIGHT_RED : (m == 3) ? LIGHT_AMBER : LIGHT_GREEN;
}

static int valueOfMode(int m) {
    return (m == 2) ? durRed : (m == 3) ? durAmber : durGreen;
}

static void enterMode(int m) {
    mode = m;
    if (mode == MODE_NORMAL) {
        enterPhase(PH_ROAD1_GREEN);             /* chạy lại chu trình với thời gian mới */
        setTimer(TMR_SECOND, 1000);
    } else {
        tempValue = valueOfMode(mode);          /* bắt đầu chỉnh từ giá trị hiện tại */
    }
}

void traffic_init(void) {
    enterMode(MODE_NORMAL);
}

/* Nút 3 (set). Luôn giữ ràng buộc đỏ = xanh + vàng, giá trị trong 1..99.
 * Giá trị không hợp lệ thì bị từ chối và số hiển thị quay về giá trị đang có hiệu lực. */
static void applyValue(void) {
    int newRed = durRed, newAmber = durAmber, newGreen = durGreen;

    switch (mode) {
    case 2: newRed   = tempValue; newGreen = newRed - durAmber;   break;   /* đổi đỏ  -> xanh = đỏ - vàng */
    case 3: newAmber = tempValue; newRed   = durGreen + newAmber; break;   /* đổi vàng -> đỏ = xanh + vàng */
    case 4: newGreen = tempValue; newRed   = newGreen + durAmber; break;   /* đổi xanh -> đỏ = xanh + vàng */
    default: return;
    }

    if (newGreen >= 1 && newAmber >= 1 && newRed <= 99) {
        durRed = newRed; durAmber = newAmber; durGreen = newGreen;
    }
    tempValue = valueOfMode(mode);
}

void fsm_mode(void) {
    /* luôn đọc (và xoá) sự kiện cả 3 nút, kể cả ở Mode 1, để không bị "dồn" sự kiện cũ sang Mode 2 */
    uint8_t evMode = button_event(0);
    uint8_t evInc  = button_event(1);
    uint8_t evSet  = button_event(2);

    if (evMode) {
        enterMode((mode >= 4) ? MODE_NORMAL : mode + 1);    /* 1 -> 2 -> 3 -> 4 -> 1 */
    }

    if (mode != MODE_NORMAL) {
        if (evInc) tempValue = (tempValue >= 99) ? 1 : tempValue + 1;
        if (evSet) applyValue();
    }
}

/* Pha nháy tính từ thời gian hệ thống: sáng nửa đầu, tắt nửa sau của mỗi 500ms.
 * Nhờ vậy luôn đúng 2Hz dù chu kỳ ngắt là 1ms, 10ms hay 100ms. */
static void fsm_blink(void) {
    uint8_t blinkOn = (getTimeMs() % BLINK_PERIOD_MS) < (BLINK_PERIOD_MS / 2);
    LightColor c = blinkOn ? colorOfMode(mode) : LIGHT_OFF;
    setLight(0, c);                                         /* cả 2 đường cùng nháy màu của mode */
    setLight(1, c);
}

static void updateDisplayBuffer(void) {
    if (mode == MODE_NORMAL) {
        setDisplayPair(0, count1);      /* cặp trên: đường 1 */
        setDisplayPair(1, count2);      /* cặp dưới: đường 2 */
    } else {
        setDisplayPair(0, tempValue);   /* cặp trên: giá trị đang chỉnh */
        setDisplayPair(1, mode);        /* cặp dưới: số mode */
    }
}

void fsm_traffic(void) {
    if (mode == MODE_NORMAL) {
        if (isTimerExpired(TMR_SECOND)) {
            setTimer(TMR_SECOND, 1000);
            count1--;
            count2--;
            switch (phase) {
            case PH_ROAD1_GREEN: if (count1 <= 0) enterPhase(PH_ROAD1_AMBER); break;
            case PH_ROAD1_AMBER: if (count1 <= 0) enterPhase(PH_ROAD2_GREEN); break;
            case PH_ROAD2_GREEN: if (count2 <= 0) enterPhase(PH_ROAD2_AMBER); break;
            case PH_ROAD2_AMBER: if (count2 <= 0) enterPhase(PH_ROAD1_GREEN); break;
            }
        }
    } else {
        fsm_blink();
    }
    updateDisplayBuffer();
}

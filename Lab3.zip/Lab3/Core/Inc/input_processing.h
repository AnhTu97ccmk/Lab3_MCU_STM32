#ifndef INC_INPUT_PROCESSING_H_
#define INC_INPUT_PROCESSING_H_

#include "main.h"

#define MODE_NORMAL 1

extern int mode;                              /* 1..4 */
extern int durRed, durAmber, durGreen;        /* giây, luôn thoả durRed = durGreen + durAmber */

void    fsm_for_input_processing(void);       /* FSM từng nút -> sinh sự kiện */
uint8_t button_event(uint8_t index);          /* đọc và xoá sự kiện của nút */
void    traffic_init(void);                   /* gọi 1 lần trước vòng while(1) */
void    fsm_mode(void);                       /* xử lý nút 1/2/3 theo mode */
void    fsm_traffic(void);                    /* Mode 1: chạy đèn; Mode 2-4: nháy đèn; cập nhật buffer LED 7 đoạn */

#endif /* INC_INPUT_PROCESSING_H_ */

#ifndef INC_INPUT_READING_H_
#define INC_INPUT_READING_H_

#include "main.h"
#include "timer.h"

#define N0_OF_BUTTONS 3          /* B1 = mode, B2 = tăng, B3 = set */

/* Quét nút mỗi 10ms (không nhanh hơn chu kỳ ngắt của timer) */
#define BUTTON_SCAN_MS         10
#define BUTTON_SCAN_TICKS      ((BUTTON_SCAN_MS >= TIMER_CYCLE) ? (BUTTON_SCAN_MS / TIMER_CYCLE) : 1)
#define BUTTON_SCAN_PERIOD_MS  (BUTTON_SCAN_TICKS * TIMER_CYCLE)

void button_init(void);
void button_reading(void);
unsigned char is_button_pressed(unsigned char index);
unsigned char is_button_pressed_1s(unsigned char index);

#endif /* INC_INPUT_READING_H_ */

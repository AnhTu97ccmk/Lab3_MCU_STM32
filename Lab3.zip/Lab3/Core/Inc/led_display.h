#ifndef INC_LED_DISPLAY_H_
#define INC_LED_DISPLAY_H_

#include "main.h"

/* Quét mỗi digit 5ms (nếu timer 10ms thì thực tế là 10ms/digit).
 * Nếu thấy LED 7 đoạn nhấp nháy, đổi timer xuống 1ms (Ex4) để quét nhanh hơn. */
#ifndef LED_SCAN_MS
#define LED_SCAN_MS 5
#endif

/* Thứ tự enum quan trọng: giá trị 1..3 dùng để chọn chỉ số chân trong led_display.c */
typedef enum {
    LIGHT_OFF   = 0,
    LIGHT_RED   = 1,
    LIGHT_AMBER = 2,
    LIGHT_GREEN = 3
} LightColor;

void display_init(void);
void setLight(uint8_t road, LightColor color);     /* road: 0 = đường 1, 1 = đường 2 (ghi vào output buffer) */
void setDisplayPair(uint8_t pair, int value);      /* pair 0 = cặp LED 7 đoạn phía trên, 1 = cặp phía dưới; value 0..99 */
void display_update(void);                         /* output driver: đẩy buffer ra chân, gọi trong while(1) */

#endif /* INC_LED_DISPLAY_H_ */

#ifndef INC_TIMER_H_
#define INC_TIMER_H_

#include "main.h"

/*
 * Chu kỳ ngắt của TIM2 (ms).
 * Khi muốn đổi chu kỳ ngắt: đổi macro này + Prescaler/Period trong CubeMX
 * (clock 8MHz):   1ms   -> PSC = 799,  ARR = 9
 *                 10ms  -> PSC = 7999, ARR = 9
 *                 100ms -> PSC = 7999, ARR = 99
 * Mọi thời gian khác trong chương trình đều tính bằng ms nên không phải sửa.
 */
#ifndef TIMER_CYCLE
#define TIMER_CYCLE 10
#endif

/* Mỗi chức năng dùng một software timer riêng */
enum {
    TMR_SECOND,   /* nhịp 1 giây của đèn giao thông (Mode 1)            */
    TMR_SCAN,     /* quét LED 7 đoạn                                    */
    TMR_BTN0,     /* tự lặp khi giữ nút 1 (dùng TMR_BTN0 + chỉ số nút)  */
    TMR_BTN1,     /* nút 2                                              */
    TMR_BTN2,     /* nút 3                                              */
    MAX_TIMER
};

void setTimer(int index, int duration_ms);
int  isTimerExpired(int index);   /* trả về 1 một lần khi hết hạn, rồi tự xoá cờ */
void timerRun(void);              /* gọi trong ngắt timer */
uint32_t getTimeMs(void);         /* thời gian hệ thống (ms) tính từ lúc bật timer */

#endif /* INC_TIMER_H_ */
